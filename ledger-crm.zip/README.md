# Ledger — CRM for Solopreneurs

Full-stack SaaS: Next.js + Tailwind frontend (Vercel), Express + Prisma + SQLite backend (Render), Stripe subscriptions in test mode.

```
crm-project/
  backend/   Express API, Prisma/SQLite, JWT auth, Stripe checkout + webhook
  frontend/  Next.js app: landing page, auth, dashboard, billing
```

## 1. Push to GitHub

```bash
cd crm-project
git init
git add .
git commit -m "Initial commit: Ledger CRM"
gh repo create ledger-crm --public --source=. --remote=origin
git push -u origin main
```

(No `gh` CLI? Create an empty repo on github.com, then `git remote add origin <url>` and `git push -u origin main`.)

Two apps in one repo is fine — Render and Vercel each let you set a "root directory" (`backend` and `frontend` respectively) so they only build their half.

## 2. Set up Stripe (test mode)

1. Create a free account at stripe.com, stay in **test mode** (toggle top-right).
2. Products → **Add product** → name it "Pro", price **$12/month recurring**. Copy the resulting Price ID (`price_...`).
3. Developers → API keys → copy the **Secret key** (`sk_test_...`).
4. Developers → Webhooks → you'll add the endpoint URL *after* the backend is deployed (step 3), since it needs a live URL.

## 3. Deploy the backend to Render

1. render.com → **New → Web Service** → connect your GitHub repo.
2. Root directory: `backend`.
3. Build command: `npm install && npx prisma generate && npx prisma migrate deploy`
4. Start command: `npm start`
5. Add a **persistent disk**: 1GB, mount path `/data` (Settings → Disks). Without this, SQLite data is wiped on every redeploy.
6. Environment variables:
   - `DATABASE_URL` = `file:/data/prod.db`
   - `JWT_SECRET` = any long random string
   - `NODE_ENV` = `production`
   - `FRONTEND_URL` = (fill in after step 4 — your Vercel URL)
   - `STRIPE_SECRET_KEY` = `sk_test_...`
   - `STRIPE_PRO_PRICE_ID` = `price_...`
   - `STRIPE_WEBHOOK_SECRET` = (fill in after step 3b below)
7. Deploy. Note the resulting URL, e.g. `https://solocrm-backend.onrender.com`.

**3b. Add the Stripe webhook now that you have the backend URL:**
- Stripe Dashboard → Developers → Webhooks → **Add endpoint**
- URL: `https://<your-render-url>/api/billing/webhook`
- Events to send: `checkout.session.completed`, `invoice.paid`, `customer.subscription.updated`, `customer.subscription.deleted`
- Copy the **Signing secret** (`whsec_...`) into Render's `STRIPE_WEBHOOK_SECRET` env var, and redeploy.

## 4. Deploy the frontend to Vercel

1. vercel.com → **Add New → Project** → import the same GitHub repo.
2. Root directory: `frontend`.
3. Framework preset: Next.js (auto-detected).
4. Environment variable: `NEXT_PUBLIC_API_URL` = your Render backend URL from step 3.
5. Deploy. Note the resulting URL, e.g. `https://ledger-crm.vercel.app`.
6. Go back to Render and set `FRONTEND_URL` to this Vercel URL, then redeploy the backend (this is what CORS and Stripe's redirect URLs use).

## 5. Test the whole flow end-to-end

1. Visit your Vercel URL → Sign up (free plan) → add a contact and a deal → refresh the page → data is still there (proves persistence).
2. Log out, log back in → session persists.
3. Go to Billing → Upgrade to Pro → use Stripe's test card `4242 4242 4242 4242`, any future expiry, any CVC.
4. After checkout redirects back, the billing page should show "Pro" within a few seconds (webhook updates your DB).
5. Try adding an 11th contact on a free account before upgrading — it should be blocked with an upgrade prompt; unlimited once on Pro.
6. Cancel the subscription from the billing page — Stripe will mark it to cancel at period end.

## Local development

**Backend:**
```bash
cd backend
cp .env.example .env   # fill in Stripe test keys
npm install
npx prisma migrate dev --name init
npm run dev             # http://localhost:4000
```

**Frontend:**
```bash
cd frontend
cp .env.example .env.local
npm install
npm run dev              # http://localhost:3000
```

## What's gated by plan

Free plan is capped at **10 contacts**; Pro is unlimited. This is enforced server-side in `backend/src/routes/contacts.js`, not just hidden in the UI.
